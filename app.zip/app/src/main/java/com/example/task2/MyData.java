package com.example.task2;

public class MyData {

    static String[] nameArray = {
            "Milk",
            "Bread",
            "Chicken",
            "Eggs",
            "Oil"
    };

    static Integer[] quantityArray = {0, 0, 0, 0, 0};

    static Double[] priceArray = {5.0, 12.5, 7.0, 10.0, 15.0};

    static Integer[] imageArray = {R.drawable.milk, R.drawable.bread, R.drawable.chicken, R.drawable.eggs, R.drawable.oil};

    static Integer[] idArray = {0, 1, 2, 3, 4};
}
